from .finny_scraper import PropertyInfo
